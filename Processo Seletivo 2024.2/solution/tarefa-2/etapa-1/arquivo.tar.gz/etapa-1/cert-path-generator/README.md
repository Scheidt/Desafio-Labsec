# Tarefa 2 - Gerar caminho de certificação

## Execução

Para executar o script, basta rodar o comando:

```bash
mvn clean compile exec:java
```

## Certificados

Os certificados necessários para a execução do script estão disponíveis na pasta `resources`.

## Instruções

As instruções da tarefa estão disponíveis no arquivo principal de execução do script, `Main.java`.
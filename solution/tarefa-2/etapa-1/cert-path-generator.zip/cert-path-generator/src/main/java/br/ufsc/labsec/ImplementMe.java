package br.ufsc.labsec;

public @interface ImplementMe {

}
